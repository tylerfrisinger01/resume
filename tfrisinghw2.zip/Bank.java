package assignment;

import java.util.ArrayList;

public class Bank implements InterestBearingAccount{
	
	
	

	public static void main(String[] args) {
	ArrayList<Account> accounts = new ArrayList<Account>();


	accounts.add(new InterestCheckingAccount("Tony Stark",313001,35881.12));
	accounts.add(new PlatinumCheckingAccount("Williams",313002,2400.00));
	accounts.add(new NonInterestCheckingAccount("Adams",313003,250002.15));
	
		display(accounts);
		
		addInterest(accounts);
		System.out.println("Adding Interests...");
		display(accounts);
	
	}
	private static void display(ArrayList<Account>accounts) {
		System.out.printf("%-30s%-30s%-30s%-30s\n","Account Holder","Account Number","Current Balance","Account Type");
		for(int i = 0; i < accounts.size();i++) {
			System.out.println(accounts.get(i));
		}
		double totalBal=totalAssets(accounts);
		System.out.println("Total balance in all accounts: $"+totalBal);
		System.out.println("-------------------------");
	}
	
	private static double totalAssets(ArrayList<Account>accounts) {
		double tot = 0;
		for(int i = 0; i < accounts.size();i++) {
			tot += accounts.get(i).getBalance();
		}
		return tot;
	}
	
	public static void addInterest(ArrayList<Account>accounts) {
		// TODO Auto-generated method stub
		for(int i = 0;i < accounts.size(); i++) {
			if(accounts.get(i) instanceof InterestCheckingAccount)
			{
		((InterestCheckingAccount)accounts.get(i)).addInterest();
	}
			else if(accounts.get(i) instanceof PlatinumCheckingAccount) {
				((PlatinumCheckingAccount)accounts.get(i)).addInterest();
			}
		}
		
	}
	
}
