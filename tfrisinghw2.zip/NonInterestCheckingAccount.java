package assignment;

public class NonInterestCheckingAccount extends Account{

	public NonInterestCheckingAccount(String name, int accNumber, double balance) {
		super(name,accNumber,balance);
	}
	
	@Override
	public String toString() {
		String s = new String().format("%s%-30s\n",super.toString(),"Non Interest");
		return s;
	}
	
}
