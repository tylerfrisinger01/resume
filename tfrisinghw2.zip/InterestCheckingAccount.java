package assignment;

public class InterestCheckingAccount extends Account{

	public InterestCheckingAccount(String name, int accNumber, double balance) {
		super(name,accNumber,balance);
	}

		public void addInterest() {
			super.deposit(getBalance() *0.03);
		}
		
		@Override
		public String toString() {
			String s = new String().format("%s%-30s\n",super.toString(),"Interest Checking");
			return s;
		}
	
	
}
