package assignment;

public class PlatinumCheckingAccount extends InterestCheckingAccount{

	public PlatinumCheckingAccount(String name, int accNumber, double balance) {
		super(name,accNumber,balance);
		
		
	}

	@Override
	public void addInterest() {
		// TODO Auto-generated method stub
		super.deposit(getBalance() * 0.06);
		
	}
	
	@Override
	public String toString() {
		String s = new String().format("%s%-30s\n",super.toString(),"Interest Checking (Platinum)");
		return s;
	}
	

}
