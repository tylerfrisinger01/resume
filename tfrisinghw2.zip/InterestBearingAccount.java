package assignment;

import java.util.ArrayList;

public interface InterestBearingAccount {

	//void addInterest();

	static void addInterest(ArrayList<Account> accounts) {
	}
}
