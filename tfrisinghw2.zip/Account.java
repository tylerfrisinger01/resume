package assignment;

public abstract class Account {

	public String name;
	public int accNumber;
	public double balance;
	
	
	public Account(String name,int accNumber, double balance) {
		this.accNumber = accNumber;
		this.balance = balance;
		this.name = name;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void deposit(double amount) {
		
		this.balance += amount;
		
	}
	
	public void withdraw(double amount) {
		if(balance-amount >0) {
			this.balance -= amount;
		}
	}
	
	@Override
	public String toString() {
		String s = new String().format("%-30s%-30d%-30.2f", name,accNumber,balance);
		return s;
	}
	
}
