module homework1 {
}