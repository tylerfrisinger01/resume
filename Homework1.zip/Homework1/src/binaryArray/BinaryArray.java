package binaryArray;

public class BinaryArray {
	//TODO: have fields

	//BinaryArray Constructor
	public BinaryArray (String s) {
		//TODO: implement constructor
		//IllegalArgumentException if s is invalid
	}

	@Override
	public String toString() {
		//TODO: implement method
		return "";
	}
	//getter method that retuns value at a specific index
	public char get(int idx) {
		//TODO: implement get method
		return 'z';
	}
	//setter function
	public void set(int idx, char value) {
		//TODO: implement set method

	}
	//gets size of binaryArray
	public int size() {
		//TODO: implement size method
		return -1;
	}

}
