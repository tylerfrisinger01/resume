package binaryArray;

public class BinaryArrayDriver {

	public static void main(String[] args) {
		// TODO: implement driver

		// prompts include:
		// Please enter a binary string:
		// Choose what you want to do: 1) print current BinaryArray 2) get a value 3)
		// set a value 4) view size 5) exit:
		// option 1
		// This binary Array has X variables: [binary array here]
		// option 2
		// Input the position you want to see:
		// Position is out of range!! Re-Input the position you want to see:
		// The element at 2 is X
		// option 3
		// Input the position you want to change and the value you want to assign to it:
		// option 4
		// The size of this binary array is: X
		// option 5
		// Goodbye
	}

}
